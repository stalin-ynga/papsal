### 0.1.4
* Works in the old android, ios browsers and other.

### 0.1.3
* Fix page scrolling bug
* Refactor CSS

### 0.1.2
* Public collection of instances. Now you can get specific instance throw JS: `var inst = $.remodal.lookup[$('[data-remodal-id=modal]').data('remodal')];`;
* Plugin constructor calling returns instance now. `var inst = $('[data-remodal-id=modal]').remodal()`.

### 0.1.1
* Zepto support!
* Blur is changed from 5px to 3px.
